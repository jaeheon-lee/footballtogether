<template>
  <div>
    <v-container fluid class="pt-0 pb-0 my-0 px-0 mx-0">
      <v-row justify="center" fluid align="start" class="py-0 my-0 px-0 mx-5">
        <v-col xl="6" lg="8" cols="12" class="py-0 my-0 px-0 mx-0">
          <v-text-field
            label="팀 찾기"
            solo
            prepend-inner-icon="search"
            color="#ffffff"
            hide-details="false"
          ></v-text-field>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>
<style scoped src="../assets/css/all.css"></style>
