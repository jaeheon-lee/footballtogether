<template>
  <v-container fluid class="pt-5 pb-0 my-0 px-0 mx-0">
    <v-row justify="center" fluid align="start" class="py-0 my-0 px-0 mx-5">
      <v-col xl="6" lg="8" cols="12" class="py-0 my-0 px-0 mx-0">
        <v-btn block color="#ebff0080" dark>팀 만들기</v-btn>
      </v-col>
    </v-row>
  </v-container>
</template>
