<template>
  <div>PrivateMenu.vue입니다.</div>
</template>
