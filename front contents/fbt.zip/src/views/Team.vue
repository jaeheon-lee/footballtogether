<template>
  <div>
    <p>Team.vue입니다.</p>
    <router-view></router-view>
  </div>
</template>
<script>
export default {};
</script>
